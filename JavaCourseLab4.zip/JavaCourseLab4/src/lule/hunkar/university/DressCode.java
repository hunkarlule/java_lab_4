package lule.hunkar.university;

public enum DressCode {
	JERSEY("jersey"), FANCY("fancy"), ANYTHING("anything"), UNIFORM("uniform"); 
 private String dressing;
 
 DressCode(String dressing) {
	 this.dressing = dressing;
 }
 
}
