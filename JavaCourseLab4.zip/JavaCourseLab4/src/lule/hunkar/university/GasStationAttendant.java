package lule.hunkar.university;

public class GasStationAttendant extends Employee implements Comparable<GasStationAttendant> {
	private double numberOfDollarsStolenPerDay;
	private final static double OVERTIME_PAY_RATE = 1.5;

	public DressCode getDressCode() {
		return DressCode.UNIFORM;
	}

	public boolean isPaidSalary() {
		return false;
	}

	public boolean postSecondaryEducationRequired() {
		return false;
	}

	public String getWorkVerb() {
		return "pump";
	}

	public double getOverTimePayRate() {
		return OVERTIME_PAY_RATE;
	}

	/**
	 * @param name
	 * @param numberOfDollarsStolenPerDay
	 */
	public GasStationAttendant(String name, double numberOfDollarsStolenPerDay) {
		super(name);
		this.numberOfDollarsStolenPerDay = numberOfDollarsStolenPerDay;
	}

	/**
	 * @return the numberOfDollarsStolenPerDay
	 */
	public double getNumberOfDollarsStolenPerDay() {
		return numberOfDollarsStolenPerDay;
	}

	/**
	 * @param numberOfDollarsStolenPerDay
	 *            the numberOfDollarsStolenPerDay to set
	 */
	public void setNumberOfDollarsStolenPerDay(double numberOfDollarsStolenPerDay) {
		this.numberOfDollarsStolenPerDay = numberOfDollarsStolenPerDay;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		long temp;
		temp = Double.doubleToLongBits(numberOfDollarsStolenPerDay);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		return result;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		GasStationAttendant other = (GasStationAttendant) obj;
		if (Double.doubleToLongBits(numberOfDollarsStolenPerDay) != Double
				.doubleToLongBits(other.numberOfDollarsStolenPerDay)) {
			return false;
		}
		return true;
	}

	public int compareTo(GasStationAttendant gasStationAttendant) {
		if (this.getNumberOfDollarsStolenPerDay() - gasStationAttendant.getNumberOfDollarsStolenPerDay() > 0)
			return 1;
		else if (this.getNumberOfDollarsStolenPerDay() - gasStationAttendant.getNumberOfDollarsStolenPerDay() < 0)
			return -1;
		else
			return 0;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "GasStationAttendant [numberOfDollarsStolenPerDay=" + numberOfDollarsStolenPerDay + ", getName()="
				+ getName() + "]";
	}

	
}
