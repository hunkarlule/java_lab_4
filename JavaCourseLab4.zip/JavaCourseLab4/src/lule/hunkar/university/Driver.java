package lule.hunkar.university;

import java.util.ArrayList;
import java.util.Collections;

public class Driver {
	public static void main(String[] args) {

		ArrayList<Professor> professors = new ArrayList<>();
		ArrayList<Parent> parents = new ArrayList<>();
		ArrayList<HockeyPlayer> hockeyPlayers = new ArrayList<>();
		ArrayList<GasStationAttendant> gasStationAttendants = new ArrayList<>();

		// adding professors arraylist
		professors.add(new Professor("Albert Einstein", "Physics"));
		professors.add(new Professor("Alan Turing", "Computer Science"));
		professors.add(new Professor("Richard Feynman", "Physics"));
		professors.add(new Professor("Tim Berners-Lee", "Computer Science"));
		professors.add(new Professor("Kurt Godel", "Logic"));

		// professors arraylist before sorting
		System.out.println("before sorting");
		for (Professor p : professors) {
			System.out.println(p);
		}
		// professors arraylist after sorting
		Collections.sort(professors);
		System.out.println("after sorting");
		for (Professor p : professors) {
			System.out.println(p);
		}
		System.out.println("=======================================");
		// adding parents arraylist
		parents.add(new Parent("Tiger Woods", 1));
		parents.add(new Parent("Super Mom", 168));
		parents.add(new Parent("Lazy Larry", 20));
		parents.add(new Parent("Ex Hausted", 168));
		parents.add(new Parent("Super Dad", 167));

		// parents arraylist before sorting
		System.out.println("before sorting");
		for (Parent p : parents) {
			System.out.println(p);
		}

		// parents arraylist after sorting
		Collections.sort(parents);
		System.out.println("after sorting");
		for (Parent p : parents) {
			System.out.println(p);
		}

		System.out.println("=======================================");
		// adding hockeyPlayers arraylist
		hockeyPlayers.add(new HockeyPlayer("Wayne Gretzky", 894));
		hockeyPlayers.add(new HockeyPlayer("Who Ever", 0));
		hockeyPlayers.add(new HockeyPlayer("Brent Gretzky", 1));
		hockeyPlayers.add(new HockeyPlayer("Pavel Bure", 437));
		hockeyPlayers.add(new HockeyPlayer("Jason Bourne", 0));

		// hockeyPlayers arraylist before sorting
		System.out.println("before sorting");
		for (HockeyPlayer p : hockeyPlayers) {
			System.out.println(p);
		}

		// hockeyPlayers arraylist after sorting
		Collections.sort(hockeyPlayers);
		System.out.println("after sorting");
		for (HockeyPlayer p : hockeyPlayers) {
			System.out.println(p);
		}
		System.out.println("=======================================");
		// adding gasStationAttendants arraylist
		gasStationAttendants.add(new GasStationAttendant("Joe Smith", 10));
		gasStationAttendants.add(new GasStationAttendant("Tony Baloney", 100));
		gasStationAttendants.add(new GasStationAttendant("Benjamin Franklin", 100));
		gasStationAttendants.add(new GasStationAttendant("Mary Fairy", 101));
		gasStationAttendants.add(new GasStationAttendant("Bee See", 1));

		// gasStationAttendants arraylist before sorting
		System.out.println("before sorting");
		for (GasStationAttendant p : gasStationAttendants) {
			System.out.println(p);
		}

		// gasStationAttendants arraylist after sorting
		Collections.sort(gasStationAttendants);
		System.out.println("after sorting");
		for (GasStationAttendant p : gasStationAttendants) {
			System.out.println(p);
		}
	}
}
