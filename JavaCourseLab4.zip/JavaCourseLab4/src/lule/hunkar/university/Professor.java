package lule.hunkar.university;

public class Professor extends Employee implements Comparable<Professor> {
	private String teachingMajor;
	private final static double OVERTIME_PAY_RATE = 2.0;

	public DressCode getDressCode() {
		return DressCode.FANCY;
	}

	public boolean isPaidSalary() {
		return true;
	}

	public boolean postSecondaryEducationRequired() {
		return true;
	}

	public String getWorkVerb() {
		return "teach";
	}

	public double getOverTimePayRate() {
		return OVERTIME_PAY_RATE;
	}

	/**
	 * @param name
	 * @param teachingMajor
	 */
	public Professor(String name, String teachingMajor) {
		super(name);
		this.teachingMajor = teachingMajor;
	}

	/**
	 * @return the teachingMajor
	 */
	public String getTeachingMajor() {
		return teachingMajor;
	}

	/**
	 * @param teachingMajor
	 *            the teachingMajor to set
	 */
	public void setTeachingMajor(String teachingMajor) {
		this.teachingMajor = teachingMajor;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((teachingMajor == null) ? 0 : teachingMajor.hashCode());
		return result;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object that) {
		if (that == null) {
			return false;
		}

		if (this == that) {
			return true;
		}

		if (getClass() != that.getClass()) {
			return false;
		}
		Professor other = (Professor) that;
		if (this.teachingMajor == null) {
			if (other.teachingMajor != null) {
				return false;
			}
		} else if (!teachingMajor.equals(other.teachingMajor)) {
			return false;
		}
		return true;
	}

	public int compareTo(Professor professor) {
		if (this.getTeachingMajor().equalsIgnoreCase("Computer Science")
				&& !(professor.getTeachingMajor().equalsIgnoreCase("Computer Science"))) {
			return 1;
		} else if (!(this.getTeachingMajor().equalsIgnoreCase("Computer Science"))
				&& professor.getTeachingMajor().equalsIgnoreCase("Computer Science")) {
			return -1;
		} else {
			return 0;
		}
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Professor [teachingMajor=" + teachingMajor + ", getName()=" + getName() + "]";
	}



}
