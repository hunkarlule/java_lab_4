package lule.hunkar.university;

public class HockeyPlayer extends Employee implements Comparable<HockeyPlayer> {
	private int numberOfGoals;
	private final static double OVERTIME_PAY_RATE = 0.0;

	public DressCode getDressCode() {
		return DressCode.JERSEY;
	}

	public boolean isPaidSalary() {
		return true;
	}

	public boolean postSecondaryEducationRequired() {
		return false;
	}

	public String getWorkVerb() {
		return "play";
	}

	public double getOverTimePayRate() {
		return OVERTIME_PAY_RATE;
	}

	/**
	 * @param name
	 * @param numberOfGoals
	 */
	public HockeyPlayer(String name, int numberOfGoals) {
		super(name);
		this.numberOfGoals = numberOfGoals;
	}

	/**
	 * @return the numberOfGoals
	 */
	public int getNumberOfGoals() {
		return numberOfGoals;
	}

	/**
	 * @param numberOfGoals
	 *            the numberOfGoals to set
	 */
	public void setNumberOfGoals(int numberOfGoals) {
		this.numberOfGoals = numberOfGoals;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + numberOfGoals;
		return result;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object that) {
		if (that == null) {
			return false;
		}
		if (this == that) {
			return true;
		}
		if (getClass() != that.getClass()) {
			return false;
		}
		HockeyPlayer other = (HockeyPlayer) that;
		if (numberOfGoals != other.numberOfGoals) {
			return false;
		}
		return true;
	}

	public int compareTo(HockeyPlayer hockeyPlayer) {
		return this.getNumberOfGoals() - hockeyPlayer.getNumberOfGoals();
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "HockeyPlayer [numberOfGoals=" + numberOfGoals + ", getName()=" + getName() + "]";
	}

	

}
