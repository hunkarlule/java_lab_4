package lule.hunkar.university;

public abstract class Employee implements Employable {
	private String name;

	public abstract double getOverTimePayRate();

	/**
	 * @param name
	 */
	public Employee(String name) {
		this.name = name;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name
	 *            the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
}
