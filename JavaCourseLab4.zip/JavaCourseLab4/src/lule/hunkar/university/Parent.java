package lule.hunkar.university;

public class Parent extends Employee implements Comparable<Parent> {
	private int numberOfHoursSpentPerWeekWithKids;
	private final static double OVERTIME_PAY_RATE = -2.0;

	public DressCode getDressCode() {
		return DressCode.ANYTHING;
	}

	public boolean isPaidSalary() {
		return false;
	}

	public boolean postSecondaryEducationRequired() {
		return false;
	}

	public String getWorkVerb() {
		return "care";
	}

	public double getOverTimePayRate() {
		return OVERTIME_PAY_RATE;
	}

	/**
	 * @param name
	 * @param numberOfHoursSpentPerWeekWithKids
	 */
	public Parent(String name, int numberOfHoursSpentPerWeekWithKids) {
		super(name);
		this.numberOfHoursSpentPerWeekWithKids = numberOfHoursSpentPerWeekWithKids;
	}

	/**
	 * @return the numberOfHoursSpentPerWeekWithKids
	 */
	public int getNumberOfHoursSpentPerWeekWithKids() {
		return numberOfHoursSpentPerWeekWithKids;
	}

	/**
	 * @param numberOfHoursSpentPerWeekWithKids
	 *            the numberOfHoursSpentPerWeekWithKids to set
	 */
	public void setNumberOfHoursSpentPerWeekWithKids(int numberOfHoursSpentPerWeekWithKids) {
		this.numberOfHoursSpentPerWeekWithKids = numberOfHoursSpentPerWeekWithKids;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + numberOfHoursSpentPerWeekWithKids;
		return result;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		Parent other = (Parent) obj;
		if (numberOfHoursSpentPerWeekWithKids != other.numberOfHoursSpentPerWeekWithKids) {
			return false;
		}
		return true;
	}

	public int compareTo(Parent parent) {
		return this.getNumberOfHoursSpentPerWeekWithKids() - parent.numberOfHoursSpentPerWeekWithKids;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Parent [numberOfHoursSpentPerWeekWithKids=" + numberOfHoursSpentPerWeekWithKids + ", getName()="
				+ getName() + "]";
	}



}
